# FlexAI Android App

🤖 **FlexAI** - Мобильное приложение для сервиса FlexAI, аналога закрытого приложения GIGA. Создавайте чат-персонажей и общайтесь с ними в любом месте!

![Platform](https://img.shields.io/badge/platform-Android-green.svg)
![API](https://img.shields.io/badge/API-24+-blue.svg)
![License](https://img.shields.io/badge/license-MIT-yellow.svg)

## ✨ Особенности

- 🌐 **WebView интерфейс** - Полный доступ к сервису FlexAI
- 💡 **Неоновый дизайн** - Стильный интерфейс в фиолетово-голубых тонах
- 🚀 **Оптимизировано для РФ** - Встроенные настройки для доступа
- 📱 **Адаптивный UI** - Поддержка всех размеров экранов
- 🔒 **Безопасность** - HTTPS соединение и защита данных
- 🎨 **Без watermark** - Скрипт для скрытия элементов Lovable

## 📋 Требования

- Android 7.0 (API 24) или выше
- Подключение к интернету
- Android Studio Arctic Fox или новее (для сборки)

## 🛠️ Установка и сборка

### Вариант 1: Android Studio (Рекомендуется)

1. **Склонируйте репозиторий:**
```bash
git clone https://github.com/yourusername/flexai-android.git
cd flexai-android
```

2. **Откройте проект в Android Studio:**
   - Запустите Android Studio
   - Выберите `File` → `Open`
   - Укажите папку с проектом `flexai-android`

3. **Дождитесь синхронизации Gradle**

4. **Подключите устройство или запустите эмулятор**

5. **Нажмите Run (▶️) или `Shift+F10`**

### Вариант 2: Сборка через командную строку

```bash
# Навигация в папку проекта
cd flexai-android

# Сборка debug версии
./gradlew assembleDebug

# Сборка release версии
./gradlew assembleRelease
```

APK файлы будут находиться в:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Вариант 3: Для пользователей APK Editor Studio

Если у вас нет Android Studio, вы можете:

1. **Собрать APK на онлайн-сервисе:**
   - [GitHub Actions](https://github.com/features/actions) - настройте CI/CD
   - [Codemagic](https://codemagic.io/) - бесплатная сборка Android приложений
   - [Bitrise](https://www.bitrise.io/) - еще один вариант облачной сборки

2. **Или попросите кого-то собрать APK** из этого исходного кода

## 🎨 Дизайн и темы

Приложение использует неоновую цветовую схему:

- **Основной цвет:** #7c4dff (фиолетовый)
- **Акцентный цвет:** #00e5ff (голубой)
- **Фон:** Градиент от #0a0a1a до #1a0a2e

### Иконка приложения

Векторная иконка в стиле AI/Neon создается программно через XML drawable.

## 🔧 Конфигурация

### Изменение URL

Если потребуется изменить URL сервиса, отредактируйте файл:
`app/src/main/java/com/flexai/app/MainActivity.kt`

```kotlin
private val BASE_URL = "https://flexai-ru.lovable.app/"
```

### Настройки WebView

В файле `MainActivity.kt` можно настроить:
- JavaScript (включен по умолчанию)
- localStorage и sessionStorage
- Геолокацию
- Mixed content режим

## 📁 Структура проекта

```
flexai-android/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/flexai/app/
│   │       │   └── MainActivity.kt
│   │       ├── res/
│   │       │   ├── drawable/
│   │       │   ├── mipmap-*/
│   │       │   ├── values/
│   │       │   └── layout/
│   │       └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## 🌐 Прокси для РФ

Для обеспечения доступа из РФ рекомендуется:

1. **Использовать VPN** на устройстве
2. **Настроить системный прокси** в настройках Android
3. **Использовать Tor Browser** для доступа

⚠️ **Важно:** Приложение само не включает прокси-сервер, так как это требует серверной инфраструктуры. Используйте внешние решения для обхода блокировок.

## 🔐 Разрешения

Приложение запрашивает следующие разрешения:
- `INTERNET` - Доступ к интернету для загрузки веб-контента
- `ACCESS_NETWORK_STATE` - Проверка состояния сети

## 🐛 Решение проблем

### Сайт не загружается
- Проверьте подключение к интернету
- Попробуйте использовать VPN
- Очистите кэш приложения

### Ошибки компиляции
- Обновите Android Studio до последней версии
- Синхронизируйте проект с Gradle files
- Очистите сборку: `Build` → `Clean Project`

### Watermark всё ещё виден
- Некоторые элементы могут быть защищены от скрытия
- Попробуйте обновить CSS селекторы в методе `injectCSS()`

## 📝 Лицензия

MIT License - свободное использование, модификация и распространение.

## 🤝 Вклад в проект

Приветствуются PR с улучшениями:
- Улучшение производительности
- Новые функции
- Исправление багов
- Улучшение дизайна

## 📞 Контакты

- Website: https://flexai-ru.lovable.app/
- Issues: [GitHub Issues](https://github.com/yourusername/flexai-android/issues)

## ⭐ Благодарности

- Сервис FlexAI за отличную платформу
- Сообществу Android разработчиков
- Всем кто использует приложение!

---

**Made with 💜 and ☕ for AI enthusiasts**
