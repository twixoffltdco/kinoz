package com.flexai.app

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    
    // Основной URL сервиса FlexAI
    private val BASE_URL = "https://flexai-ru.lovable.app/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Создаем layout программно
        val rootLayout = android.widget.FrameLayout(this)
        rootLayout.setBackgroundColor(android.graphics.Color.parseColor("#0a0a1a"))
        
        webView = WebView(this)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleLarge)
        
        val params = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT
        )
        
        val progressParams = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
        )
        progressParams.gravity = android.view.Gravity.CENTER
        
        rootLayout.addView(webView, params)
        rootLayout.addView(progressBar, progressParams)
        
        setContentView(rootLayout)
        
        // Настройка WebView
        setupWebView()
        
        // Загрузка сайта
        webView.loadUrl(BASE_URL)
    }
    
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webSettings: WebSettings = webView.settings
        
        // Включаем JavaScript
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.databaseEnabled = true
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        
        // Включаем localStorage
        webSettings.javaScriptCanOpenWindowsAutomatically = true
        webSettings.setSupportMultipleWindows(false)
        
        // Zoom settings
        webSettings.setSupportZoom(true)
        webSettings.builtInZoomControls = true
        webSettings.displayZoomControls = false
        
        // Modern viewport
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true
        
        // Геолокация (если нужна)
        webSettings.geolocationEnabled = true
        
        // Mixed content для HTTPS
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        
        // WebViewClient для обработки навигации
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }
            
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                
                // Инъекция CSS для скрытия watermark (если есть)
                injectCSS()
            }
            
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Все ссылки открываются в этом же WebView
                return false
            }
        }
        
        // WebChromeClient для прогресса загрузки
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress == 100) {
                    progressBar.visibility = View.GONE
                } else {
                    progressBar.visibility = View.VISIBLE
                }
            }
        }
    }
    
    private fun injectCSS() {
        val css = """
            javascript:(function() {
                var style = document.createElement('style');
                style.innerHTML = `
                    /* Скрытие возможных watermark */
                    [class*="watermark"],
                    [class*="lovable"],
                    [id*="watermark"],
                    footer[class*="footer"],
                    div[style*="lovable"] {
                        display: none !important;
                    }
                    
                    /* Неоновый стиль для элементов */
                    body {
                        background: linear-gradient(135deg, #0a0a1a 0%, #1a0a2e 100%) !important;
                    }
                `;
                document.head.appendChild(style);
            })();
        """
        webView.evaluateJavascript(css, null)
    }
    
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
