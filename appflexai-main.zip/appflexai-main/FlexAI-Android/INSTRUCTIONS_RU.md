# FlexAI Android - Исходный код приложения

Это полный исходный код Android-приложения для сервиса FlexAI.

## 📦 Что внутри

- Полный проект Android Studio
- Готовая конфигурация Gradle
- Kotlin код основного activity
- Ресурсы (иконки, темы, цвета)
- README для GitHub

## 🚀 Быстрый старт

1. Откройте эту папку в Android Studio
2. Дождитесь синхронизации Gradle
3. Нажмите Run

## 📱 Сборка APK без Android Studio

### Онлайн-сервисы:
- **Codemagic**: https://codemagic.io/
- **Bitrise**: https://www.bitrise.io/
- **GitHub Actions**: Настройте workflow в репозитории

### Инструкция для Codemagic:
1. Зарегистрируйтесь на codemagic.io
2. Подключите GitHub репозиторий
3. Выберите шаблон "Android"
4. Запустите сборку
5. Скачайте готовый APK

## ⚙️ Технические детали

- **Язык**: Kotlin
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **WebView**: Android System WebView
- **Тема**: Material Design с неоновыми акцентами

## 🎨 Особенности дизайна

- Неоновый градиент фона (#0a0a1a → #1a0a2e)
- Фиолетовые акценты (#7c4dff)
- Голубые элементы (#00e5ff)
- Векторная AI-иконка

## 🔧 Для продвинутых пользователей

### Изменение URL
Отредактируйте `app/src/main/java/com/flexai/app/MainActivity.kt`:
```kotlin
private val BASE_URL = "https://flexai-ru.lovable.app/"
```

### Настройка proxy
Добавьте системные настройки прокси в коде или используйте VPN приложение.

### Улучшение скрытия watermark
Измените CSS в методе `injectCSS()` в MainActivity.kt

## 📄 Лицензия

MIT License
